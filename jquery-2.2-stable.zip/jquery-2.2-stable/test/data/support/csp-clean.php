<?php
	file_put_contents("csp.log", "", LOCK_EX);
?>
